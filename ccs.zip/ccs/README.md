== For CCS Review only ==

# Installation
1. `wget https://raw.githubusercontent.com/emp-toolkit/emp-readme/master/scripts/install.py`
2. `python install.py --deps --tool --ot --zk`

## Test
   `./run ./test_protocol`
